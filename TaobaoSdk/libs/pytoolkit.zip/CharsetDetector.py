#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim: set ts=4 sts=4 sw=4 et:
'''
@author: wul
@contact: 
@date: Mar 8, 2011 9:59:32 AM
@version: 0.0.0
@license: New BSD License
'''

def detectCharset(s):
    from chardet import detect
    from django.utils.encoding import smart_str
#    import magic

    s = smart_str(s)
#    magicResult = magic.Magic(mime_encoding=True).from_buffer(s)
    chardetResult = detect(s)["encoding"]
    charset = None
    if "utf-8" in chardetResult.lower():
        charset = "utf-8"
    elif chardetResult:
        charset = chardetResult
    else:
        charset = None
    return charset

if __name__ == '__main__':
    charset = detectCharset(file(__file__).read())
    print charset
