#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim: set ts=4 sts=4 sw=4 et:
'''
@author: wul
@contact: 
@date: Jan 19, 2011 2:53:50 PM
@version: 0.0.0
@license: New BSD License
'''

def getIsDebug(**kargs):
    '''判断是否是debug'''
    if kargs.has_key('isDebug'):
        return kargs['isDebug']
    return False

def joinPath(path, *args):
    import os
    for subPath in args:
        path = os.path.join(path, subPath)
    return normalizePath(path)

def normalizePath(path):
    import os
    return os.path.normpath(os.path.realpath(path))

def getIsCFile(unknownFile):
    '''
    判断是否是C/C++文件，包括头文件和源文件
    '''

    return getIsCHeader(unknownFile) or getIsCSourceFile(unknownFile)

def getIsCSourceFile(unknownFile):
    '''
    判断是否是C/C++的源文件
    '''
    import mimetypes
    mimetypes.init()
    import os

    cMimeTypes = [
        'text/x-csrc',
        'text/x-c++src',
    ]

    cSuffix = ['.c', '.cc', '.cpp', '.cxx']

    fileMimeType = mimetypes.guess_type(unknownFile)
    if fileMimeType[0] in cMimeTypes:
        return True
    if os.path.splitext(unknownFile)[1] in cSuffix:
        return True
    return False

def getIsCHeader(unknownFile):
    '''
    判断是否是C/C++的头文件
    '''
    import mimetypes
    mimetypes.init()
    import os
    cMimeTypes = [
        'text/x-chdr',
        'text/x-c++hdr',
    ]
    headerSuffix = ['.h', '.hh', '.hpp', '.hxx']

    fileMimeType = mimetypes.guess_type(unknownFile)
    if fileMimeType[0] in cMimeTypes:
        return True
    if os.path.splitext(unknownFile)[1] in headerSuffix:
        return True
    return False

def getProjectCFiles(projectPath, callback=getIsCFile):
    import os
    files = list()
    for root, dirnames, filenames in os.walk(projectPath):
        for filename in filenames:
            filepath = os.path.join(root, filename)
            if callback(filepath):
                files.append(filepath)
    return files

def writeFile(filename, *args):
    import os
    fileStream = file(filename, "w")
    for s in args:
        fileStream.write(str(s) + os.linesep)
    fileStream.close()

def getLocalIP():
    import socket
    s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    port = socket.getservbyname("http","tcp")
    s.connect(("www.baidu.com",port))
    return s.getsockname()[0]

def encode(s, toCharset='utf-8'):
    import chardet
#    from Decoder import Decoder
#    import unicodedata
#    decoder = Decoder()
#    uStr = decoder.decodeStr(s)
#    #return unicodedata.normalize("NFKD", uStr).encode(toCharset, "ignore")
#    return uStr.encode(toCharset)
    try:
        newStr = s.decode(chardet.detect(str(s))['encoding']).encode(toCharset)
    except Exception:
        newStr = s
    return newStr

def getStringSimilarity(s1, s2, ignoreAll=False):
    from difflib import SequenceMatcher
    if ignoreAll:
        for i in range(0, 33):
            s1 = s1.replace(chr(i), str())
            s2 = s2.replace(chr(i), str())
        s1 = s1.replace(chr(127), str())
        s2 = s2.replace(chr(127), str())
    sequenceMatcher = SequenceMatcher(None, s1, s2)
    return sequenceMatcher.ratio()

def getArchitecture():
    import platform
    results = list()
    results.append(platform.system())
    results.extend(platform.architecture())
    return results

def getCPUNums():
    import os
    systemInfo = getArchitecture()
    if systemInfo[0] == "Linux":
        if hasattr(os, "sysconf"):
            if os.sysconf_names.has_key("SC_NPROCESSORS_ONLN"):
                # Linux & Unix:
                ncpus = os.sysconf("SC_NPROCESSORS_ONLN")
                if isinstance(ncpus, int) and ncpus > 0:
                    return ncpus
            else: # OSX
                return int(os.popen2("sysctl -n hw.ncpu")[1].read())
        return 1
    else:
        if os.environ.has_key("NUMBER_OF_PROCESSORS"):
            ncpus = int(os.environ["NUMBER_OF_PROCESSORS"])
            if ncpus > 0:
                return ncpus
        return 1
