#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim: set ts=4 sts=4 sw=4 et:
'''
@author: wul
@contact: 
@date: Sep 28, 2010 3:53:45 PM
@version: 0.0.0
@license: New BSD License
'''

from argparse import *
from optparse import *