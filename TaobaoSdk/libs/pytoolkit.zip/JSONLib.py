#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim: set ts=4 sts=4 sw=4 et:
'''
@author: garcia
@contact: 
@date: Mar 13, 2011 10:00:12 AM
@version: 0.0.0
@license: New BSD License
对JSON格式的字符串进行decode和encode操作
'''

def encode(iterable):
    '''
    将iterable转换为一个JSON格式的字符串
    '''
    import copy
    import demjson
    import simplejson

    result = None
    try:
        result = demjson.encode(copy.deepcopy(iterable))
    except Exception:
        try:
            result = simplejson.dumps(copy.deepcopy(iterable))
        except Exception:
            import zope.component
            import z3c.json
            jsonWriter = zope.component.getUtility(
                z3c.json.interfaces.IJSONWriter)
            result = jsonWriter.write(copy.deepcopy(iterable))
    return result

def decode(jsonStr):
    '''
    将jsonStr转换为原本描述的数据格式
    '''
    import copy
    import demjson
    import simplejson

    result = None
    try:
        result = simplejson.loads(copy.deepcopy(jsonStr))
    except Exception:
        try:
            result = demjson.decode(copy.deepcopy(jsonStr))
        except Exception:
            try:
                from d9t.json import parser
                domParser = parser.JsDomParser(copy.deepcopy(jsonStr))
                result = domParser.parse()
            except Exception:
                import zope.component
                import z3c.json
                jsonReader = zope.component.getUtility(
                    z3c.json.interfaces.IJSONReader)
                result = jsonReader.read(copy.deepcopy(jsonStr))
    return result

if __name__ == '__main__':
    iterable = {
        "a":1,
        "b":2,
        }
    print encode(iterable)
    jsonStr = "[1,2,3]"
    print decode(jsonStr)