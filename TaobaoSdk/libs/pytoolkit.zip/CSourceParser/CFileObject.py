#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim: set ts=4 sts=4 sw=4 et:
'''
@author: wul
@contact: 
@date: Jan 19, 2011 4:30:54 PM
@version: 0.0.0
@license: New BSD License
'''

from CSourceParserImporter import *

class CFileObject(BaseClass):
    def __init__(self, **kargs):
        super(self.__class__, self).__init__(**kargs)
        self.files = list()  # 其中保存着这个文件的一个个symbol信息