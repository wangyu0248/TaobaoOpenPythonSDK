#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim: set ts=4 sts=4 sw=4 et:
'''
@author: wul
@contact: 
@date: Jan 19, 2011 11:46:03 PM
@version: 0.0.0
@license: New BSD License
'''

from CSourceParserImporter import *
from TagsGenerator import TagsGenerator
from TagsParser import TagsParser
from EndLineFinder import EndLineFinder

class TestEndLineFinder(unittest.TestCase):
    def setUp(self):
        self.cFile = None

    def tearDown(self):
        if os.path.exists(self.cFile):
            os.remove(self.cFile)
        try:
            del self.cfiles
        except Exception:
            pass

    def getCFiles(self):
        writeFile(self.cFile, self.cCode)
        tagsGenerator = TagsGenerator(projectPath=self.cFile, isDeleteTags=True)
        tagsGenerator.generateTags()
        tagsParser = TagsParser(tagsFile=tagsGenerator.tagsFile)
        cfiles = tagsParser.parse()
        endlineFinder = EndLineFinder(cfiles=cfiles)
        self.cfiles = endlineFinder.getEndLines()
        del tagsGenerator

    def testGetEndLine(self):
        '''
        测试最简单的得到class、function的结束行号
        '''
        functionName = sys._getframe().f_code.co_name
        self.cFile = joinPath(tempfile.gettempdir(), functionName +'.h')
        self.cCode = '''
class TestClass {
};
'''
        self.getCFiles()
        self.assertEqual(self.cfiles[self.cFile][0].endLine, 3)

    def testFunctionNameIsMultiLine(self):
        '''
        测试当函数名占据了多行的情况
        '''
        functionName = sys._getframe().f_code.co_name
        self.cFile = joinPath(tempfile.gettempdir(), functionName +'.h')
        self.cCode = '''
void print(int& a
    int& b) {
    a = b;
}
'''
        self.getCFiles()
        self.assertEqual(self.cfiles[self.cFile][0].endLine, 5)

    def testIfHasSingleComment(self):
        '''
        如果在这个class、function中包含comment
        '''
        functionName = sys._getframe().f_code.co_name
        self.cFile = joinPath(tempfile.gettempdir(), functionName +'.h')
        self.cCode = '''
class TestClass {
// This is comment
};
'''
        self.getCFiles()
        self.assertEqual(self.cfiles[self.cFile][0].endLine, 4)

    def testIfHasSingleCommentWithBracket(self):
        '''
        测试在单条的comment中包含“}”
        '''
        functionName = sys._getframe().f_code.co_name
        self.cFile = joinPath(tempfile.gettempdir(), functionName +'.h')
        self.cCode = '''
class TestClass {
// This is comment }
};
'''
        self.getCFiles()
        self.assertEqual(self.cfiles[self.cFile][0].endLine, 4)

    def testIfLineNotStartswithSingleComment(self):
        '''
        测试如果该行不仅仅只有注释
        '''
        functionName = sys._getframe().f_code.co_name
        self.cFile = joinPath(tempfile.gettempdir(), functionName +'.h')
        self.cCode = '''
class TestClass {
TestClass() {} // This is comment
};
'''
        self.getCFiles()
        for symbol in self.cfiles[self.cFile]:
            if symbol.startLine == 3:
                self.assertEqual(symbol.endLine, 3)
            if symbol.startLine == 2:
                self.assertEqual(symbol.endLine, 4)

    def testIfHasCommentsBlock(self):
        '''
        测试如果包含注释块
        '''
        functionName = sys._getframe().f_code.co_name
        self.cFile = joinPath(tempfile.gettempdir(), functionName +'.h')
        self.cCode = '''
class TestClass {
/*
 * This is comment
 */
};
'''
        self.getCFiles()
        self.assertEqual(self.cfiles[self.cFile][0].endLine, 6)

    def testIfHasBracketInCommentsBlock(self):
        '''
        测试如果在注释块中有{或者}
        '''
        functionName = sys._getframe().f_code.co_name
        self.cFile = joinPath(tempfile.gettempdir(), functionName +'.h')
        self.cCode = '''
class TestClass {
/* }
 * This is comment }
 */
};
'''
        self.getCFiles()
        self.assertEqual(self.cfiles[self.cFile][0].endLine, 6)

    def testFunctionNotEndswithBracket(self):
        '''
        测试如果函数不endswith({)
        '''
        functionName = sys._getframe().f_code.co_name
        self.cFile = joinPath(tempfile.gettempdir(), functionName +'.h')
        self.cCode = '''
class TestClass
{
};
'''
        self.getCFiles()
        self.assertEqual(self.cfiles[self.cFile][0].endLine, 4)

    def testGetTwoClassEndLine(self):
        '''
        测试得到两个class、function的endLine
        '''
        functionName = sys._getframe().f_code.co_name
        self.cFile = joinPath(tempfile.gettempdir(), functionName +'.h')
        self.cCode = '''
class TestClass {
};
void testFunction() {
}
'''
        self.getCFiles()
        for symbol in self.cfiles[self.cFile]:
            if symbol.startLine == 2:
                self.assertEqual(symbol.endLine, 3)
            if symbol.startLine == 4:
                self.assertEqual(symbol.endLine, 5)