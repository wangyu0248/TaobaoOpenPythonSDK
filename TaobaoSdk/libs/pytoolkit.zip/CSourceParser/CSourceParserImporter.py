#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim: set ts=4 sts=4 sw=4 et:
'''
@author: wul
@contact: 
@date: Jan 19, 2011 2:55:52 PM
@version: 0.0.0
@license: New BSD License
'''

import os
import sys

currentPath = os.path.normpath(os.path.join(os.path.realpath(__file__),
    os.path.pardir))
projectPath = os.path.normpath(os.path.join(currentPath, os.path.pardir))
sys.path.insert(0, projectPath)

from BaseClass import BaseClass
from ctags import CTags, TagEntry
import platform
import tempfile
from Utility import *
import unittest

# 设置
binPath = joinPath(currentPath, 'bin')
if platform.architecture()[0].startswith('32'):
    ctagsBinary = joinPath(binPath, 'ctags32')
elif platform.architecture()[0].startswith('64'):
    ctagsBinary = joinPath(binPath, 'ctags64')