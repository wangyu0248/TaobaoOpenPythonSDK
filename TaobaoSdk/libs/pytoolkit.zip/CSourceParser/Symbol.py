#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim: set ts=4 sts=4 sw=4 et:
'''
@author: wul
@contact: 
@date: Jan 19, 2011 4:27:45 PM
@version: 0.0.0
@license: New BSD License
'''

from CSourceParserImporter import *

class Symbol(BaseClass):
    def __init__(self, **kargs):
        super(self.__class__, self).__init__(**kargs)
        self.name = None
        self.type = None
        self.startLine = None
        self.endLine = None
        self.language = None
