#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim: set ts=4 sts=4 sw=4 et:
'''
@author: wul
@contact: 
@date: Jan 20, 2011 12:27:41 PM
@version: 0.0.0
@license: New BSD License
'''

import getpass
import os
import sys

currentPath = os.path.normpath(os.path.join(os.path.realpath(__file__),
    os.path.pardir))
sys.path.insert(0, currentPath)

from BaseClass import BaseClass

class ProjectGuesser(BaseClass):
    @staticmethod
    def guessProjectName(path):
        '''
        根据输入的路径来猜测项目名
        '''
        path = os.path.normpath(os.path.realpath(path))
        fields = path.split(os.path.sep)
        fields.reverse()
        invalildNames = (
            'trunk',
            'test',
            'src',
            'include',
            )
        projectName = str()
        for field in fields:
            isInvaildField = False
            for invaildName in invalildNames:
                if invaildName in field:
                    isInvaildField = True
                    break
            if isInvaildField:
                continue
            return field != str() and field or getpass.getuser()

if __name__ == '__main__':
    print ProjectGuesser.guessProjectName(sys.argv[1])