#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim: set ts=4 sts=4 sw=4 et:
'''
@author: wul
@contact: 
@date: Jan 19, 2011 2:58:20 PM
@version: 0.0.0
@license: New BSD License
'''

from Colorful import printColorful
from Utility import *
from threading import Timer

class BaseClass(object):
    '''
    所有类的基类
    '''
    def __init__(self, **kargs):
        self.kargs = kargs
        self.__isDebug = getIsDebug(**self.kargs)
        self.isDebug = self.__isDebug
        self.__classname = str(self.__class__)
        self.__logPrintDelay = 1

    def hasAttribute(self, name):
        '''
        判断是否含有name这个属性
        '''
        return self.__dict__.has_key(name)

    def getIsValidParameter(self, name):
        if self.kargs.has_key(name) and self.kargs[name] is not None:
            return True
        return False

    def getIsValidParameter2(self, key, **kargs):
        return kargs.has_key(key) and kargs[key]

    def getParameterValue(self, name, isFaultTolerant=False):
        if not isFaultTolerant:
            return self.kargs[name]
        else:
            try:
                return self.kargs[name]
            except Exception:
                return None

    def infoMessage(self, *messages):
        for message in messages:
            message = "[%s]\t%s" % (self.__classname, message)
#            printColorful('green', message)
            try:
                timer = Timer(self.__logPrintDelay, printColorful,
                    args=('green', message))
                timer.start()
            except Exception:
                pass

    def debugMessage(self, *messages):
        if self.__isDebug:
            for message in messages:
                message = "[%s]\t%s" % (self.__classname, message)
#                printColorful('blue', message)
                try:
                    timer = Timer(self.__logPrintDelay, printColorful,
                        args=('blue', message))
                    timer.start()
                except Exception:
                    pass

    def warnMessage(self, *messages):
        if self.__isDebug:
            for message in messages:
                message = "[%s]\t%s" % (self.__classname, message)
#                printColorful('yellow', message)
                try:
                    timer = Timer(self.__logPrintDelay, printColorful,
                        args=('yellow', message))
                    timer.start()
                except Exception:
                    pass

    def errorMessage(self, *messages):
        import sys
        for message in messages:
            message = "[%s]\t%s" % (self.__classname, message)
            try:
                printColorful('red', message, outputStream=sys.stderr)
            except Exception:
                pass

    def updateParameters(self, **kargs):
        import copy
        results = copy.deepcopy(self.kargs)
        results.update(kargs)
        return results