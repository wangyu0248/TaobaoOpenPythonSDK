#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim: set ts=4 sts=4 sw=4 et:
'''
@author: wul
@contact: 
@date: Feb 22, 2011 7:19:33 PM
@version: 0.0.0
@license: New BSD License
'''

from BaseClass import BaseClass
from Decoder import Decoder

class ServiceInterface(BaseClass):
    _cp_config = {'tools.sessions.on': True}

    def __init__(self, **kargs):
        super(self.__class__, self).__init__(**kargs)
        self.templatePath = self.getParameterValue("templatePath")
        self.decoder = Decoder()

    def render(self, templateFile, **kargs):
        from mako.runtime import Context
        from mako.lookup import TemplateLookup
        from mako.template import Template

        kargs = self.decoder.decodeAny(kargs)
        lookup = TemplateLookup(directories=[self.templatePath],
            input_encoding='utf-8')
        templater = lookup.get_template(templateFile)
        try:
            return [templater.render_unicode(**kargs).encode('utf-8')]
        except Exception:
            return templater.render_unicode(**kargs)